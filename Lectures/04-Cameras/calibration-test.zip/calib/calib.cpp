
#include <iostream>
#include <stdexcept>
#include <opencv2/opencv.hpp>
#include <boost/thread.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

using namespace std;
using namespace cv;
using namespace boost::posix_time;


class FrameData
{
public:
    Mat _matFrame;
    vector<Point2f> _vPoints;
    FrameData(Mat &matFrame, vector<Point2f> &vPoints);
};

FrameData::FrameData(Mat &matFrame, vector<Point2f> &vPoints)
{
    _matFrame = matFrame;
    _vPoints = vPoints;
}


class CalibData
{
private:
    vector<FrameData> _vFrameData;
    int _width;
    int _height;
    Size _boardSize;
    double _dSquareSize;
    vector<vector<Point3f> > _vvObjectPoints;
    vector<vector<Point2f> > _vvImagePoints;
    Mat _matK;
    Mat _matDistCoeffs;
    vector<Mat> _vMatRotvecs;
    vector<Mat> _vMatTransvecs;
    double _dRmsError;

public:
    CalibData(int boardCols, int boardRows, double dSquareSize);
    void addFrame(Mat &matFrame, vector<Point2f> vPoints);
    void calibrate();
    void saveParams(string sFilename);
};


CalibData::CalibData(int boardCols, int boardRows, double dSquareSize)
{
    _width = 0;
    _height = 0;
    _boardSize = Size(boardCols, boardRows);
    _dSquareSize = dSquareSize;
    _dRmsError = 0;
}


void CalibData::addFrame(Mat &matFrame, vector<Point2f> vPoints)
{
    FrameData frameData(matFrame, vPoints);
    _vFrameData.push_back(frameData);
    if (_vFrameData.size() == 1)
    {
        _width = matFrame.cols;
        _height = matFrame.rows;
    }
    else
    {
        if (_width != matFrame.cols || _height != matFrame.rows)
        {
            runtime_error("Inconsistent image size");
        }
    }
    ostringstream sLabel;
    sLabel << "IMAGE_" << _vFrameData.size();
    imshow(sLabel.str(), matFrame);
}


void CalibData::calibrate()
{
    for (int iImage = 0; iImage < _vFrameData.size(); iImage++)
    {
        vector<Point2f> vImagePoints;
        for (int iPoint = 0; iPoint < _vFrameData[iImage]._vPoints.size(); iPoint++)
        {
            vImagePoints.push_back(_vFrameData[iImage]._vPoints[iPoint]);
        }
        _vvImagePoints.push_back(vImagePoints);
    }
    _vvObjectPoints.resize(1);
    _vvObjectPoints[0].clear();
    for (int iRow = 0; iRow < _boardSize.height; iRow++)
    {
        for (int iCol = 0; iCol < _boardSize.width; iCol++)
        {
            _vvObjectPoints[0].push_back(Point3f(iCol * _dSquareSize, iRow * _dSquareSize, 0));
        }
    }
    _vvObjectPoints.resize(_vvImagePoints.size(), _vvObjectPoints[0]);
    _matK = Mat::eye(3, 3, CV_64F);
    _matDistCoeffs = Mat::zeros(8, 1, CV_64F);
    _dRmsError = calibrateCamera(_vvObjectPoints, _vvImagePoints, Size(_width, _height), _matK, _matDistCoeffs,
            _vMatRotvecs, _vMatTransvecs);
    cout << "RMS error: " << _dRmsError << endl;
    cout << "K: " << _matK << endl;
}


void CalibData::saveParams(string sFilename)
{
    cout << "Saving calibration results to file \"" << sFilename << "\"" << endl;

    // Adapted from OpenCV calibration sample code

    FileStorage fs(sFilename, FileStorage::WRITE);

    time_t tt;
    time( &tt );
    struct tm *t2 = localtime( &tt );
    char buf[1024];
    strftime( buf, sizeof(buf)-1, "%c", t2 );

    fs << "calibration_time" << buf;
    fs << "nframes" << (int)_vMatRotvecs.size();
    fs << "image_width" << _width;
    fs << "image_height" << _height;
    fs << "board_width" << _boardSize.width;
    fs << "board_height" << _boardSize.height;
    fs << "square_size" << _dSquareSize;
    fs << "camera_matrix" << _matK;
    fs << "distortion_coefficients" << _matDistCoeffs;
    fs << "rms error" << _dRmsError;
}


void captureLoop(VideoCapture &videoCapture, CalibData &calibData)
{
    Mat matFrame;
    Mat matFrameGray;
    ptime timestampLastDetection;
    Size sizeBoard(9,6);

    if (!videoCapture.isOpened())
    {
        throw runtime_error("Cannot open capture device");
    }

    for (long iFrame = 0; ; iFrame++)
    {
        // Capture and timestamp next frame

        videoCapture >> matFrame;
        ptime timestamp = microsec_clock::local_time();
        cout << "Frame " << iFrame << " @ " << timestamp << endl;

        // Convert to gray scale

        cvtColor(matFrame, matFrameGray, CV_BGR2GRAY);
        vector<Point2f> vPoints;
        bool bFound = findChessboardCorners(matFrameGray, sizeBoard, vPoints,
                CV_CALIB_CB_ADAPTIVE_THRESH + CV_CALIB_CB_NORMALIZE_IMAGE + CALIB_CB_FAST_CHECK);
        if (bFound)
        {
            cornerSubPix( matFrameGray, vPoints, Size(11,11),
                    Size(-1,-1), TermCriteria( CV_TERMCRIT_EPS+CV_TERMCRIT_ITER, 30, 0.1 ));
        }
        Mat matFrameDisplay = matFrame.clone();
        drawChessboardCorners(matFrameDisplay, sizeBoard, Mat(vPoints), bFound);

        imshow("Calib image", matFrameDisplay);

        bool bQuit = false;
        char keypress = waitKey(1);
        switch(keypress)
        {
        case 'a': calibData.addFrame(matFrameDisplay, vPoints); break;
        default: if (keypress >= 0) bQuit = true; break;
        }
        if (bQuit) break;
    }
}


int main(void)
{
    VideoCapture videoCapture(0);
    CalibData calibData(9, 6, 0.0238);
    captureLoop(videoCapture, calibData);
    calibData.calibrate();
    calibData.saveParams("calib_data.yml");
    return 0;
}

